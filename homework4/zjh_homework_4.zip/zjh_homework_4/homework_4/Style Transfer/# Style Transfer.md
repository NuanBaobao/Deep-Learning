# 姓名
- 张进华
# 学号
- 201900150221
# 实验日期
- 2021.11.4
# 实验题目 **Style Transfer**
> 实现使用卷积神经网络的图像风格迁移，一般的想法是拍摄两个图像，并产生一个反映一个内容但另一个艺术“风格”的新图像。首先制定一个损失函数来匹配深度网络特征空间中每个图像的内容和风格，然后对图像本身的像素执行梯度下降。用作特征提取器的深度网络是 SqueezeNet，这是一个在 ImageNet 上训练过的小模型，体积小且效率高

# 实验步骤

## 步骤一 Content Loss

通过将损失函数组合生成一张反映一张图的内容和另一张图的风格的图片，惩罚图片内容的偏移和风格的偏移，然后使用这个混合损失函数进行梯度下降，不是对模型的参数，而是对源图的像素值

内容损失评估了生成图像的特征图与源图像的特征图有多大区别，只关心网络其中一层的内容表达，将对重构空间为一维的特征图进行运算，计算内容损失部分在整体损失中的损失权值。

内容损失计算公式：
$$
$L_c = w_c \times \sum_{i,j} (F_{ij}^{\ell} - P_{ij}^{\ell})^2$
$$
内容损失实现关键代码如下：

```python
def content_loss(content_weight, content_current, content_original):
    # Compute the content loss for style transfer.
    temp = (content_current - content_original) ** 2
    content_loss = content_weight * torch.sum(temp)
    return content_loss
```

测试内容损失显示结果如下:

<img src="D:\DeepLearning\zjh_homework_4\content_loss.png" alt="content_loss" style="zoom:100%;" />



## 步骤二 Style Loss

首先，计算一个用于表示每个滤波器的相关程度的Gram矩阵G，其中F与之前一样。Gram矩阵是一个协方差矩阵的近似，我们希望生成图片的激励状态与风格图片的激励状态相匹配，使(近似)协方差相匹配是其中的一种方法。你能用很多种方法完成，但Gram矩阵很好计算且在实践中有一个好结果，所以它很不错。
给定特征图形状为，Gram矩阵形状是， 它的项为:
$$
G_{ij}^\ell  = \sum_k F^{\ell}_{ik} F^{\ell}_{jk}
$$
假设 Gℓ是由当前图片的特征图算得的Gram矩阵， Aℓ是源图片的特征图算得的Gram矩阵， wℓ是可调权重，那么 ℓ层的风格损失可以用两Gram矩阵的加权欧几里得距离表示:
$$
L_s^\ell = w_\ell \sum_{i, j} \left(G^\ell_{ij} - A^\ell_{ij}\right)^2
$$
通常我们会计算一组层 LL的风格损失而不是单独一层 ℓ；完整风格损失是每一层风格损失的和:
$$
L_s = \sum_{\ell \in \mathcal{L}} L_s^\ell
$$
计算Gram矩阵关键代码如下

```python
shape = features.size()
features = features.view([shape[0],shape[1],-1])

transpose_features = features.clone()
   
transpose_features = transpose_features.permute(0,2,1)
    
result = torch.matmul(features, transpose_features)
if normalize:
    result = result / (shape[0]*shape[1]*shape[2]*shape[3])
return result
```

然后实现style_loss 函数，关键代码如下

```python
style_losses = 0
for i in range(len(style_layers)):
    idx = style_layers[i]
    style_losses += content_loss(style_weights[i], 
                                     gram_matrix(feats[idx]), 
                                     style_targets[i])
return style_losses
```

## 步骤三 Total-variation regularization

实际上对图像的平滑是有帮助的。我们可以通过在损失函数中添加一个用于处理像素值毛刺或者说整体偏差的项来实现。
你可以通过求每个像素与其周围相邻(水平或垂直)像素的差的平方和的累计值计算整体偏差。在这里我们求3个输入通道(RGB)的整体方差正则化的和，并用参数对其加权。
$$
L_{tv} = w_t \times \left(\sum_{c=1}^3\sum_{i=1}^{H-1}\sum_{j=1}^{W} (x_{i+1,j,c} - x_{i,j,c})^2 + \sum_{c=1}^3\sum_{i=1}^{H}\sum_{j=1}^{W - 1} (x_{i,j+1,c} - x_{i,j,c})^2\right)
$$
TV损失的定义实现关键代码如下 

```python
shape = img.size()
row_cur = img[:, :, :-1, :]
row_lat = img[:, :, 1:, :]
col_cur = img[:, :, :, :-1]
col_lat = img[:, :, :, 1:]
row_result = row_lat - row_cur
col_result = col_lat - col_cur
row_result = row_result * row_result
col_result = col_result * col_result    
result = tv_weight * (torch.sum(row_result) + torch.sum(col_result))
return result
```

## 步骤五  Generate some pretty pictures
## 步骤六 Feature Inversion
